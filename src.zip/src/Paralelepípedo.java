public class Paralelepípedo {
    public static double calcularQuadrangular(double comprimento,double altura,double largura) {
        double volume = 0.0;
        volume = comprimento * largura * altura ;
        return volume;
    }
}

