public class Cubo {
    public static double calcularCubo(double lado) {
        double volume = 0.0;
        volume = lado * lado * lado;
        return volume;
    }
}
